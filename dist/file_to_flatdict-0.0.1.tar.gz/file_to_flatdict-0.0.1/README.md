# Config Settings

This is a simple package. 
## 1.to_flatdict(filepath-->str)
In this package you can convert a .cfg, .yml file to flat dictionary.
To convert the given file to flat dictionary, to_flatdict function is available.
to write your content.
